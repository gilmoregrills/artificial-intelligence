INSERT INTO Department VALUES (1,'Engineering');
INSERT INTO Department VALUES (2,'Mathematics');
INSERT INTO Department VALUES (3,'Budget');
INSERT INTO Department VALUES (4,'Health & Beauty');
